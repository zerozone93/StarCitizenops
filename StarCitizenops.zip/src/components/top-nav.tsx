import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { SignOutButton } from "@/components/sign-out-button";
import { MobileNavDrawer } from "@/components/mobile-nav-drawer";

type TopNavProps = {
  title?: string;
  subtitle?: string;
};

export async function TopNav({ title, subtitle }: TopNavProps) {
  const session = await getServerSession(authOptions);

  return (
    <header className="border-b border-orange-300/20 bg-gradient-to-r from-slate-900/90 via-slate-900/85 to-orange-950/35 px-4 py-3 lg:px-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between md:gap-4">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-[0.2em] text-orange-100/80 sm:text-xs">{subtitle || "Operations planning platform"}</p>
          <h2 className="mt-1 text-xl font-semibold text-orange-50 sm:text-2xl">{title || "Mission Control"}</h2>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-sm md:justify-end">
          <MobileNavDrawer />
          <Link className="hidden rounded-lg border border-cyan-300/35 bg-cyan-400/10 px-3 py-1.5 text-cyan-100 hover:bg-cyan-300/20 sm:inline-flex" href="/dashboard">
            Dashboard
          </Link>
          {session?.user ? (
            <>
              <Link className="hidden rounded-lg border border-orange-300/35 bg-orange-400/10 px-3 py-1.5 text-orange-100 hover:bg-orange-300/20 md:inline-flex" href="/operations/new">
                New Op
              </Link>
              <Link className="hidden rounded-lg border border-cyan-300/35 bg-cyan-400/10 px-3 py-1.5 text-cyan-100 hover:bg-cyan-300/20 md:inline-flex" href="/ai-planner">
                AI
              </Link>
              <Link
                className="rounded-lg border border-cyan-300/35 bg-cyan-400/10 px-3 py-1.5 text-cyan-100 hover:bg-cyan-300/20 transition-colors"
                href="/social"
                title="Messages & Chat"
              >
                Chat
              </Link>
              <Link
                className="rounded-lg border border-amber-300/35 bg-amber-400/10 px-3 py-1.5 text-amber-100 hover:bg-amber-300/20 transition-colors"
                href="/notifications"
                title="Notifications"
              >
                Alerts
              </Link>
              <span className="hidden max-w-40 truncate text-slate-200 xl:inline">
                {session.user.name || session.user.email}
              </span>
              <SignOutButton className="hidden rounded-lg border border-orange-300/40 bg-orange-400/10 px-3 py-1.5 text-orange-100 hover:bg-orange-300/20 sm:inline-flex" />
            </>
          ) : (
            <Link className="rounded-lg border border-orange-300/40 bg-orange-400/10 px-3 py-1.5 text-orange-100 hover:bg-orange-300/20" href="/login">
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
